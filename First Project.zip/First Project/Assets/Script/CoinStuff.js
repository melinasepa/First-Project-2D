﻿/*This is to collect coins and make them 
disappear after they are picked up*/

#pragma strict

public var points : int = 5;
public var pickedUpBy : String = "Player";

/*Public varibles will 
show up in unity editor*/

function OnTriggerEnter2D(other : Collider2D)// checks for collision
{

	if (other.CompareTag(pickedUpBy) ) //if tere is a collision, do these two things
	{
		Debug.Log("Coins! Worth " +points+ "points!"); //give 5 points

		Destroy(gameObject); //destroy oneself

	}

}